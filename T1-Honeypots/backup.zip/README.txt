Extract with password: admin123
